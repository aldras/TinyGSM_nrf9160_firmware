This release includes FOTA update from mfw_nrf9160_1.2.1 release to mfw_nrf9160_1.2.3 release.
FOTA update filename is mfw_nrf9160_update_from_1.2.1_to_1.2.3.bin.

This release includes FOTA update from mfw_nrf9160_1.2.2 release to mfw_nrf9160_1.2.3 release.
FOTA update filename is mfw_nrf9160_update_from_1.2.2_to_1.2.3.bin.

This release includes FOTA-TEST images between mfw_nrf9160_1.2.3 release and mfw_nrf9160_1.2.3-FOTA-TEST image.
FOTA test update filenames are mfw_nrf9160_update_from_1.2.3_to_1.2.3-FOTA-TEST and mfw_nrf9160_update_from_1.2.3-FOTA-TEST_to_1.2.3.

UUID of mfw_nrf9160_1.2.3 is 0191538f-d3a5-4fe9-8f54-ba7cad9460c0
UUID of mfw_nrf9160_1.2.3-FOTA-TEST is ab0fdbbb-2dba-4817-b0cd-013edfa9215b